import React from 'react'

export default function Loading() {
  return (
    <div style={{fontSize:'30px'}}>loading</div>
  )
}
